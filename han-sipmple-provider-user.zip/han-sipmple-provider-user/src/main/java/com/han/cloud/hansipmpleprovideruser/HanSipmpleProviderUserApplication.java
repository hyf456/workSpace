package com.han.cloud.hansipmpleprovideruser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HanSipmpleProviderUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(HanSipmpleProviderUserApplication.class, args);
	}
}
