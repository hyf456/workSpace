package com.han.cloud.hansipmpleconsumermovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HanSipmpleConsumerMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(HanSipmpleConsumerMovieApplication.class, args);
	}
}
